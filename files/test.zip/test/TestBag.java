package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import collections.Bag;

import org.junit.Assert;

class TestBag {


	  private int[] values1 = {3, -2 , 45, 2 , 3, 5, -7, 10, 3, -17};
	  private int[] values2 = {3, -2 , 56, 2 , 3, 5, 22, 10, 3, -17}; // somewhat different
	  
	  private Bag bag;
	
	// Method cardinality is tested indirectly in all test methods.
	
	  @BeforeEach
	  void setUp() throws Exception {
	    bag = new Bag();
	  }

	  @Test
	  void testEmptyBag() {
	    assertEquals(0, bag.length(), "Method length: An empty bag should have length 0");
	    // int[] elems = bag.getElems();
	    // assertEquals(0, elems.length, "Method length: An empty bag should have length 0");
	  }
	
	@Test
	void testAddToEmptyBag() {
		bag.add(1);
		assertEquals(1, bag.cardinality(1));
    	assertEquals(1, bag.length(), "Method add: The length of the bag after the call bag.add(1) on an empty bag should be 1.");
    	int[] elems = bag.getElems();
    	assertTrue(elems[0]==1);
	}
	
	@Test
	void testAddToNonEmptyBag() {
		bag.add(1); bag.add(2); bag.add(2); bag.add(3);
		
        bag.add(2);
		assertEquals(3, bag.cardinality(2), "Method add: The cardinality of elem 2 should be 3 after adding 2 to the bag {1, 2, 2, 3}.");
    	assertEquals(5, bag.length(), "Method add: The length should be 5 after adding elem 2 to the bag  {1, 2, 2, 3}.");
    	
	}
	

	
	 @Test
 	 void testRemoveHappyPath() {
		 bag.add(1); bag.add(2); bag.add(2); bag.add(3);
		 boolean res = bag.remove(1);
		 assertEquals(0, bag.cardinality(1), "Method remove: The cardinality of elem 1 must be 0 after the call remove(1) on the bag {1, 2, 2, 3}.");
	     assertEquals(3, bag.length(), "Method remove: The length of the bag {1,2,2,3} after the call remove(1) must be 3.");
	     assertTrue(res, "Method remove: The return value of the call bag.remove(1) on the bag {1, 2, 2, 3} must be true.");
		 // TODO: add invariant test
	     
	     res = bag.remove(2);
	     assertEquals(1, bag.cardinality(2), "Method remove: After the call remove(2) on the bag {2, 2, 3}, the cadinality of 2 must be 1.");
	     assertEquals(2, bag.length(), "Method remove: After the call remove(2) on the bag {2, 2, 3}, the length of the bag must be 2.");
	     assertTrue(res, "Method remove: The return value of the call bag.remove(2) on the bag {2, 2, 3} must be true.");
		 // TODO: add invariant test
	 }

	 @Test
	 void testRemoveNonHappyPathLengthZero() {
	    boolean res = bag.remove(1);
	    assertEquals(0, bag.length(), "Method remove: After the call remove(1) on an empty bag, the length of that bag should be 0.");
	    assertFalse(res, "Method remove: The return value of the call bag.remove(1) on an empty bag must be false.");
	    // TODO: add invariant test
	 } 

	 @Test
	 void testRemoveNonHappyPathBagContainsEl() {
	    bag.add(1); bag.add(2); bag.add(2); bag.add(3);
		boolean res = bag.remove(4);
        assertEquals(4, bag.length(), "Method remove: The length of the bag {1,2,2,3} after the call remove(4) must be 4.");
		assertFalse(res, "Method remove: The return value of the call bag.remove(4) on the bag {1, 2, 2, 3} must be false.");
		// TODO: add invariant test
	 }

 	 
	 @Test
	  void testGetElemsEmpty() {
	    int[] expected = {};
	    assertArrayEquals(expected, bag.getElems(), "Method getElems: The result value of a call getElems() on an empty bag must be an empty array.");
	  }
	  
	  @Test
	  void testGetElemsFilled() {
	    fillBag(bag, values1);
	    boolean res = Arrays.equals(values1,bag.getElems());
	    assertTrue(res);
	  }
	  
	  @Test
	  void testCardinalityEmptyBag() {
	    assertEquals(0, bag.cardinality(4), "Method cardinality: The cardinality of an element in an empty bag must be 0.");
	  }
	  
	  @Test
	  void testCardinalityFilledBagZero() {
	    fillBag(bag, values1); 
	    assertEquals(0, bag.cardinality(100), "Method cardinality: The cardinality of an element not occuring in a non-empty bag must be zero.");
	  }
	  
	  @Test
	  void testCardinalityFilledBagOne() {
	    fillBag(bag, values1); 
	    assertEquals(1, bag.cardinality(-17), "Method cardinality: The cardinality of an element occuring once in a non-empty bag must be 1.");
	  }
	  
	  @Test
	  void testCardinalityFilledBagMOre() {
	    fillBag(bag, values1);
	    assertEquals(3, bag.cardinality(3), "Method cardinality: The cardinality of an element occuring n times (n>0) in a non-empty bag must be n.");
	  }
	  
	  @Test
	  void testEqualsNull() {
	    assertFalse(bag.equals(null), "Method equals: the call equals(null) on an empty bag must be false.");
	    fillBag(bag, values1);
	    assertFalse(bag.equals(null), "Method equals: the call equals(null) on a non-empty bag must be false.");
	  }
	 
	  @Test
	  void testEqualsObject() {
	    Object obj = new Object();
	    assertFalse(bag.equals(obj), "Method equals: the call equals(new Object) on an empty bag must be false.");
	    fillBag(bag, values1);
	    assertFalse(bag.equals(obj), "Method equals: the call equals(new Object) on a non-empty bag must be false.");
	  }

	  @Test
	  void testEqualsEmpty() {
	    Bag otherBag = new Bag();
	    assertTrue(bag.equals(otherBag), "Method equals: Two empty bags are equal.");
	    fillBag(otherBag, values1);
	    assertFalse(bag.equals(otherBag), "Method equals: An empty bag and a non-empty bag are not equal.");
	    assertFalse(otherBag.equals(bag), "Method equals: A non-empty bag and an empty bag are not equal.");
	  }

	  @Test
	  void testEqualsDifferentLength() {
	    Bag otherBag = new Bag();
	    fillBag(bag, values1);
	    fillBag(otherBag, values1);
	    fillBag(otherBag, values1);
	    assertFalse(bag.equals(otherBag), "Method equals: Two bags with different length are not equal.");
	    assertFalse(otherBag.equals(bag), "Method equals: Two bags with different length are not equal.");
	  }
	  
	  @Test
	  void testEqualsEqualLength() {
	    Bag otherBag = new Bag();
	    fillBag(bag, values1);
	    assertTrue(bag.equals(bag), "Method equals: The equals method must implement an equivalent relation on non-null objects that is reflexive, i.e. for any non-null reference value x, x.equals(x) should return true.");
	    
	    fillBag(otherBag, values1);
	    assertTrue(bag.equals(otherBag), "Method equals: Two bags with the same elements in the same order should be equal.");
	    
	    otherBag = new Bag();
	    for (int i = values1.length - 1; i >= 0; i--) {
	      otherBag.add(values1[i]);
	    }
	    assertTrue(bag.equals(otherBag), "Method equals: Two bags with the same elements in a different order should be equal.");
	    
	    otherBag = new Bag();
	    fillBag(otherBag, values2);
	    assertFalse(bag.equals(otherBag), "Method equals: Two bags with the same length, but different elements are not equal.");
	    assertFalse(otherBag.equals(bag), "Method equals: Two bags with the same length, but different elements are not equal.");
	  }

	 private static void fillBag(Bag bag, int[] with) {
		    for (int i = 0; i < with.length; i++) {
		      bag.add(with[i]);
		    }
		  }
		    
	private static int[] sortedCopy(int[] a) {
	  int[] c = a.clone();
		    Arrays.sort(c);
		    return c;
		  }



}
