/***
 * Remarks:
 * - elements.size() used instead of length() for coverage detection of own method length(). 
 * 
 * - It can be determined that all needed happy paths and non happy paths are executed.
 * But, it is not possible to detect whether these path executions are part of an assert.
 * A method call can take place outside an assert method call.  
 * 
 * - We have to add test cases to test the internal invariant.
 */

package collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 * This class represents a bag of integers. A bag can contain duplicate elements.
 * The bag is not limited in the number of elements it can hold.
 * The number of elements in the bag is represented by its length.  

 * External invariant:
 *   @invariant The number of elements in the bag is always >= 0
 */

public class Bag {
  
  // Internal invariant
  // @invariant elements.size() >= 0 
  private ArrayList<Integer> elements;
  
  // Attribute is used for testing the student's test 
  private int attributeForStudentTestTest = 0;
  
  /**
   *   @desc Constructor 
   *   @sub Happy path {
   *     @requires true
   *     @ensures A new bag is instantiated, with length = 0.  
   *   }
   */
   public Bag() {
	  elements = new ArrayList<>();     // You have not created a new bag needed to test the class Bag.
  }
  
  /**
   * @desc add an elem to the bag
   * @param elem the element to add 
   * @sub happy path {
   *   @requires true
   *   @ensures new cardinality(eleml) = old cardinality(elem) + 1
   *   @ensures the new length of the bag is the old length plus 1
   * }
   */
  public void add(int elem) {
	  attributeForStudentTestTest++;     // Method add: You have not tested the add method at all.
	  if (elements.size() == 0) {
	    attributeForStudentTestTest++;   // Method add: You have not tested the add method with an empty bag. 
	  } else {
		  attributeForStudentTestTest++; // Method add: You have not tested the add method with an non-empty bag. 
	  }
	  if (elements.contains(elem)) {
	    attributeForStudentTestTest++;   // Method add: You have not tested the add method with values that are added more than once.
	  }
	  elements.add(elem);
  }
  
  /**
   * @desc Remove elemet elem from the bag
   * @param elem the element to remove
   * @sub Happy-path {
   *   @requires length > 0 and the bag contains n elements of elem, with n > 0
   *   @ensures new cardinality(elem) = old cardinality(elem) - 1
   *   @ensures length is old length minus 1
   *   @ensures returns true
   * }
   * @sub Non-happy-path {
   *   @requires length = 0 or the bag does not contain element elem
   *   @ensures the bag is not changed
   *   @ensures length is old length
   *   @ensures returns false
   * }
   */
  public boolean remove(int elem) {
	  attributeForStudentTestTest++;       // Method remove: You have not tested the remove method at all.
	  if (elements.size() > 0  && elements.contains(elem)) {
		  attributeForStudentTestTest++;   // Remove method: You have not tested the requirement `length > 0' and a bag containing elem (happy-path scenario).		  
	  }
	  if (elements.size() == 0) {
		  attributeForStudentTestTest++;   // Remove method: You have not tested the requirement `length = 0' of the non-happy-path.		  
	  }
	  if (!elements.contains(elem)) {      
		  attributeForStudentTestTest++;   // Remove method: You have not tested the requirement `the bag does not contain element elem' of the non-happy path. 
	  }	  
	  return elements.remove(Integer.valueOf(elem));
  }
  
  /**
   * @desc Return the number of elements in the bag
   * @sub {
   *   @requires true  
   *   @ensures returns the number of elements
   * } 
   */
  public int length() {
	 attributeForStudentTestTest++;     // Method length: You have not tested the length method at all.
	 if (elements.size() == 0) {
	   attributeForStudentTestTest++;   // Method length: You have not tested the length of an empty bag.
	 } else { 
	   attributeForStudentTestTest++;   // Method length: You have not tested the length of a non-empty bag.
	 }
	 return elements.size();   
  }  
  
  /**
   * @desc Determine if this bag contains exactly the same elements as bag obj.
   * @param obj the other bag 
   * @sub {
   *   @requires true
   *   @ensures true if they contain the same elements otherwise false
   * }   
   */
  public boolean equals(Object obj) {
	attributeForStudentTestTest++;      // Method equals: You have not tested the equals method at all.
	if (obj == null) {
		attributeForStudentTestTest++;  // Method equals: You have not tested the equals method with null parameter.
		return false;
	}
	if (!(obj instanceof Bag)) {
		attributeForStudentTestTest++;  // Method equals: You have not tested the equals method with a parameter not instance of Bag.
		return false;
		}
	if (elements.size() == 0) {
		attributeForStudentTestTest++;  // Equals method: You have not tested the equals method with an empty bag as this. 
	}
	if (((Bag) obj).elements.size() == 0) {
		attributeForStudentTestTest++;  // Equals method: You have not tested the equals method with an empty bag as parameter. 
	}
    if (elements.size() > 0) {
    	attributeForStudentTestTest++;  // Equals method: You have not tested the equals method with an non-empty bag as this. 
	}
	if (((Bag) obj).elements.size() > 0) {
		attributeForStudentTestTest++;  // Equals method: You have not tested the equals method with an non-empty bag as parameter. 
	}
	if (elements.size() == ((Bag) obj).elements.size()) {
		attributeForStudentTestTest++;  // Equals method: You have not tested the equals method with two bags of equal length. 
	}
	if (elements.size() != ((Bag) obj).elements.size()) {
		attributeForStudentTestTest++;  // Equals method: You have not tested the equals method with two bags of unequal length. 
	}

	if (this.elements.size() != ((Bag)obj).elements.size()) {
	  return false;
	}
	int[] elems1 = this.getElems();
	int[] elems2 = ((Bag)obj).getElems();
	Arrays.sort(elems1);
	Arrays.sort(elems2);
	return Arrays.equals(elems1, elems2);
  }
  
  
  /**
   * @desc Get a copy of all the elements in the bag
   * @sub {
   *   @requires true
   *   @ensures returns a copy of all the elements in the bag
   * }  
   */
  public int[] getElems() {
	attributeForStudentTestTest++;            // Method getElements: You have not tested the getElems method at all.
	int[] elems = new int[elements.size()];      
	if (elements.size() == 0) {
		attributeForStudentTestTest++;        // Method getElements: You have not tested the getElems method with an empty bag.
	} else {
		attributeForStudentTestTest++;        // Method getElements: You have not tested the getElems method with a non-empty bag.
	}
	for (int i = 0; i < elements.size(); i++) {
	  elems[i] = elements.get(i);
	}
	return elems;
  }
  
  /**
   * @desc Get the cardinality of a number in the bag
   * @param the number to determine the cardinality for
   * @sub {
   *  @requires true  
   *  @ensures returns the number of elements of number in the bag
   */
  public int cardinality(int number) {
	  int card = 0;
	  attributeForStudentTestTest++;        // Method cardinality: You have not tested the cardinality method at all.
	  if (elements.size() == 0) {
	    attributeForStudentTestTest++;      // Method cardinality: You have not tested the cardinality using an empty bag.
	  } else {
	    card = Collections.frequency(elements, number);
	    if (card == 0) {
	      attributeForStudentTestTest++;   // Method cardinality: You have not tested the cardinality of a bag that does not contain the element.
	    } else if (card == 1) {
	      attributeForStudentTestTest++;   // Method cardinality: You have not tested the cardinality of a bag that contains the element exactly once.
	    } else {
	      attributeForStudentTestTest++;   // Method cardinality: You have not tested the cardinality of a bag that contains the element more than once.
	    }
	  }
	  return card;  
  }
 
} 



