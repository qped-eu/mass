class Even {
	public boolean isTrue(int num) {
		if (num % 2 == 0) {
			return true;
		} else {
			return false;
		}
	}	
}
