import com.sun.jdi.connect.Connector;

import java.util.ArrayList;
import java.util.List;

public abstract class Enigma {
    //@mass_cvStart("1111","Message","FULLY_MISSED","supMessages")
    int position;
     int nextPosition;
    abstract char scramble(char c,int position);

    Enigma(int nextPosition){
        this.nextPosition=nextPosition;
    }
    public char transform(char c){
        return scramble(c,position);
    }
    public void setConfiguration(int position){
        this.position=position;
    }
    public boolean turnRotor(){
        if(position==nextPosition){
            //drehe zylender
            return true;

        }
        else return false;
    }
    //@mass_cvEnd("1111")
}
