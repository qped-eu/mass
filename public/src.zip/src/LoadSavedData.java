
import weka.core.Instances;
import weka.core.converters.CSVLoader;

import java.io.*;

public class LoadSavedData {

    //@mass_cvStart("111","Message","FULLY_MISSED","supMessages")
    public Instances loadData(String path) throws IOException {
        CSVLoader csvLoader=new CSVLoader();
        csvLoader.setSource(new File(path));
         Instances data=csvLoader.getDataSet();
         return data;

    }

    //@mass_cvEnd("111")
}
