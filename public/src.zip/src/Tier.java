public abstract class Tier {
     abstract String makeSound();
}
