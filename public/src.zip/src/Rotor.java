import com.sun.jdi.connect.Connector;

public abstract class Rotor {
    //@mass_cvStart("11","Message","FULLY_MISSED","supMessages")
    int position;
    final int nextPosition;
    abstract char scramble(char c,int position);

    Rotor(int nextPosition){
        this.nextPosition=nextPosition;
    }
    public char transform(char c){
        return scramble(c,position);
    }
    public void setConfiguration(int position){
        this.position=position;
    }
    public boolean turnRotor(){
        if(position==nextPosition){
            //drehe zylender
            return true;

        }
        else return false;
    }
    //@mass_cvEnd("11")
}
