
public class Main {
    public static void main(String[] args) {
        System.out.println(euler(150));
        int b=6;
        System.out.println(1&b);
        Tier a=new Cat() ;
    }
    public static  double euler(int k){
        int fac=fact(k);
        if(k==0)
            return 1;
        return (double) 1 / fac
                + euler(k-1);
    }
    public static int fact(int k){

        if(k==0)
            return 1;
        else return k*fact(k-1);
    }
}