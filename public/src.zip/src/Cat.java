class Cat extends Tier {

    @Override
    public String makeSound() {
        return "meow";
    }
}
